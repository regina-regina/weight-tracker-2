import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Dimensions,
  RefreshControl,
  TouchableOpacity,
} from 'react-native';
import { LineChart } from 'react-native-gifted-charts';
import { Card } from '../components/Card';
import { colors } from '../styles/colors';
import { supabase } from '../services/supabase';
import {
  calculateWeightLossForecast,
  calculateBodyFat,
} from '../utils/calculations';
import { paces } from '../utils/constants';

const screenWidth = Dimensions.get('window').width;

export const ChartsScreen = () => {
  const [userData, setUserData] = useState(null);
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [weightPeriod, setWeightPeriod] = useState('month');
  const [bodyFatPeriod, setBodyFatPeriod] = useState('month');
  const [forecastPeriod, setForecastPeriod] = useState('all');

  const loadData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Получаем данные пользователя
      const { data: userProfile } = await supabase
        .from('users')
        .select('*')
        .eq('id', user.id)
        .single();

      setUserData(userProfile);

      // Получаем все записи
      const { data: entriesData } = await supabase
        .from('entries')
        .select('*')
        .eq('user_id', user.id)
        .order('date', { ascending: true });

      setEntries(entriesData || []);
    } catch (error) {
      console.error('Ошибка загрузки данных:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.loadingText}>Загрузка...</Text>
      </View>
    );
  }

  if (!userData || entries.length === 0) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.emptyText}>Недостаточно данных</Text>
        <Text style={styles.emptySubtext}>
          Добавьте несколько записей для построения графиков
        </Text>
      </View>
    );
  }

  // Функция фильтрации данных по периоду
  const filterDataByPeriod = (data, period) => {
    if (period === 'all') return data;
    
    const now = new Date();
    const cutoffDate = new Date();
    
    if (period === 'week') {
      cutoffDate.setDate(now.getDate() - 7);
    } else if (period === 'month') {
      cutoffDate.setMonth(now.getMonth() - 1);
    }
    
    return data.filter((entry) => new Date(entry.date) >= cutoffDate);
  };

  // Данные для графика веса
  const filteredWeightEntries = filterDataByPeriod(entries, weightPeriod);
  const weightData = filteredWeightEntries.length > 0 ? filteredWeightEntries.map((e, index) => {
    // ИСПРАВЛЕНО: Парсим дату как локальную
    const [year, month, day] = e.date.split('-');
    const label = `${day}/${month}`;
    return {
      value: e.weight,
      label: filteredWeightEntries.length > 1 && index % Math.ceil(filteredWeightEntries.length / 5) === 0 ? label : '',
      date: e.date,
      dataPointText: `${e.weight}`,
    };
  }) : [];

  // Данные для графика процента жира
  const bodyFatEntries = entries.filter((e) => e.waist && e.neck);
  const filteredBodyFatEntries = filterDataByPeriod(bodyFatEntries, bodyFatPeriod);
  const bodyFatData = filteredBodyFatEntries.map((e, index) => {
    // ИСПРАВЛЕНО: Парсим дату как локальную
    const [year, month, day] = e.date.split('-');
    const label = `${day}/${month}`;
    const bodyFat = calculateBodyFat(
      userData.gender,
      e.waist,
      e.neck,
      userData.height,
      e.hips
    );
    return {
      value: bodyFat,
      label: index % Math.ceil(filteredBodyFatEntries.length / 5) === 0 ? label : '',
      date: e.date,
      dataPointText: `${bodyFat.toFixed(1)}%`,
    };
  });

  // Прогнозы для всех темпов
  const currentWeight = entries[entries.length - 1].weight;
  const forecasts = paces.map((pace) => ({
    ...pace,
    data: calculateWeightLossForecast(
      currentWeight,
      userData.goal_weight,
      pace.value
    ),
  }));

  // Находим самый длинный прогноз
  const maxForecastLength = Math.max(...forecasts.map((f) => f.data.length));

  // Фильтруем прогнозы по периоду
  const getForecastPointsCount = (period) => {
    if (period === 'week') return 2;
    if (period === 'month') return 4;
    return maxForecastLength;
  };

  const forecastPointsCount = getForecastPointsCount(forecastPeriod);

  // Исторические данные (последние 3 точки или меньше, если нет данных)
  const historicalData = entries.length > 0 ? entries.slice(-Math.min(3, entries.length)).map((e, index) => {
    // ИСПРАВЛЕНО: Парсим дату как локальную
    const [year, month, day] = e.date.split('-');
    const label = `${day}/${month}`;
    return {
      value: e.weight,
      label: index === 0 || index === entries.slice(-Math.min(3, entries.length)).length - 1 ? label : '',
      dataPointText: '',
    };
  }) : [];

  // Формируем данные прогнозов для каждого темпа
  const forecastDatasets = entries.length > 0 ? forecasts.map((forecast) => {
    const forecastPoints = forecast.data.slice(1, forecastPointsCount + 1).map((point, index) => {
      // ИСПРАВЛЕНО: Форматируем дату прогноза правильно
      const date = new Date(point.date);
      const day = date.getDate();
      const month = date.getMonth() + 1;
      const label = `${day}/${month}`;
      return {
        value: point.weight,
        label: index % Math.max(1, Math.ceil(forecastPointsCount / 4)) === 0 ? label : '',
        dataPointText: '',
      };
    });
    
    return {
      color: forecast.color,
      label: forecast.label,
      data: [...historicalData, ...forecastPoints],
    };
  }) : [];

  // Компонент переключателя периодов
  const PeriodSelector = ({ period, setPeriod, options }) => (
    <View style={styles.periodSelector}>
      {options.map((option) => (
        <TouchableOpacity
          key={option.value}
          style={[
            styles.periodButton,
            period === option.value && styles.periodButtonActive,
          ]}
          onPress={() => setPeriod(option.value)}
        >
          <Text
            style={[
              styles.periodButtonText,
              period === option.value && styles.periodButtonTextActive,
            ]}
          >
            {option.label}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );

  const periodOptions = [
    { value: 'week', label: 'Неделя' },
    { value: 'month', label: 'Месяц' },
    { value: 'all', label: 'Все' },
  ];

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <Text style={styles.headerTitle}>Графики</Text>
      </View>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl refreshing={Boolean(refreshing)} onRefresh={onRefresh} />
        }
      >

      {/* График веса */}
      <Card color={colors.pastelPink}>
        <Text style={styles.cardTitle}>📈 Изменение веса</Text>
        <PeriodSelector period={weightPeriod} setPeriod={setWeightPeriod} options={periodOptions} />
        {weightData.length > 0 ? (
          <View style={styles.chartContainer}>
            <LineChart
              data={weightData}
              width={screenWidth - 96}
              height={180}
              curved
              areaChart
              isAnimated
              animationDuration={1000}
              startFillColor={colors.chartPink}
              startOpacity={0.4}
              endFillColor={colors.chartPink}
              endOpacity={0.1}
              color={colors.chartPink}
              thickness={3}
              hideDataPoints={false}
              dataPointsColor={colors.chartPink}
              dataPointsRadius={5}
              spacing={Math.min(50, Math.max(20, (screenWidth - 140) / Math.max(1, weightData.length)))}
              initialSpacing={10}
              endSpacing={10}
              noOfSections={4}
              yAxisColor="transparent"
              xAxisColor={colors.tabBarBorder}
              yAxisTextStyle={styles.axisText}
              xAxisLabelTextStyle={styles.axisText}
              showVerticalLines={false}
              rulesColor={colors.tabBarBorder}
              rulesType="solid"
              adjustToWidth={true}
              pointerConfig={{
                pointerStripHeight: 140,
                pointerStripColor: colors.textSecondary,
                pointerStripWidth: 2,
                pointerColor: colors.chartPink,
                radius: 6,
                pointerLabelWidth: 100,
                pointerLabelHeight: 90,
                activatePointersOnLongPress: false,
                autoAdjustPointerLabelPosition: false,
                pointerLabelComponent: items => {
                  return (
                    <View style={styles.tooltip}>
                      <Text style={styles.tooltipValue}>{items[0].value} кг</Text>
                      <Text style={styles.tooltipLabel}>{items[0].date}</Text>
                    </View>
                  );
                },
              }}
            />
          </View>
        ) : (
          <Text style={styles.noDataText}>Недостаточно данных для построения графика</Text>
        )}
      </Card>

      {/* График процента жира */}
      {bodyFatData.length > 0 && (
        <Card color={colors.pastelMint}>
          <Text style={styles.cardTitle}>💪 Процент жировой массы</Text>
          <PeriodSelector period={bodyFatPeriod} setPeriod={setBodyFatPeriod} options={periodOptions} />
          <View style={styles.chartContainer}>
            <LineChart
              data={bodyFatData}
              width={screenWidth - 96}
              height={180}
              curved
              areaChart
              isAnimated
              animationDuration={1000}
              startFillColor={colors.chartMint}
              startOpacity={0.4}
              endFillColor={colors.chartMint}
              endOpacity={0.1}
              color={colors.chartMint}
              thickness={3}
              hideDataPoints={false}
              dataPointsColor={colors.chartMint}
              dataPointsRadius={5}
              spacing={Math.min(50, Math.max(20, (screenWidth - 140) / Math.max(1, bodyFatData.length)))}
              initialSpacing={10}
              endSpacing={10}
              noOfSections={4}
              yAxisColor="transparent"
              xAxisColor={colors.tabBarBorder}
              yAxisTextStyle={styles.axisText}
              xAxisLabelTextStyle={styles.axisText}
              showVerticalLines={false}
              rulesColor={colors.tabBarBorder}
              rulesType="solid"
              adjustToWidth={true}
              pointerConfig={{
                pointerStripHeight: 140,
                pointerStripColor: colors.textSecondary,
                pointerStripWidth: 2,
                pointerColor: colors.chartMint,
                radius: 6,
                pointerLabelWidth: 100,
                pointerLabelHeight: 90,
                activatePointersOnLongPress: false,
                autoAdjustPointerLabelPosition: false,
                pointerLabelComponent: items => {
                  return (
                    <View style={styles.tooltip}>
                      <Text style={styles.tooltipValue}>{items[0].value.toFixed(1)}%</Text>
                      <Text style={styles.tooltipLabel}>{items[0].date}</Text>
                    </View>
                  );
                },
              }}
            />
          </View>
        </Card>
      )}

      {/* Прогнозы */}
      <Card color={colors.pastelLavender}>
        <Text style={styles.cardTitle}>🔮 Прогноз снижения веса</Text>
        <PeriodSelector period={forecastPeriod} setPeriod={setForecastPeriod} options={periodOptions} />
        
        {forecastDatasets.length > 0 && forecastDatasets[0].data.length > 0 ? (
          <>
            <Text style={styles.legendTitle}>Темпы похудения и даты достижения цели:</Text>
            {forecasts.map((forecast) => {
              const lastPoint = forecast.data[forecast.data.length - 1];
              const goalDate = new Date(lastPoint.date);
              const goalDateStr = `${goalDate.getDate()}.${goalDate.getMonth() + 1}.${goalDate.getFullYear()}`;
              
              return (
                <View key={forecast.value} style={styles.legendItem}>
                  <View style={[styles.legendDot, { backgroundColor: forecast.color }]} />
                  <View style={styles.legendTextContainer}>
                    <Text style={styles.legendText}>{forecast.label}</Text>
                    <Text style={styles.legendDate}>Цель к {goalDateStr}</Text>
                  </View>
                </View>
              );
            })}

            <View style={styles.chartContainer}>
              <LineChart
                data={forecastDatasets[0].data}
                data2={forecastDatasets[1]?.data}
                data3={forecastDatasets[2]?.data}
                width={screenWidth - 96}
                height={180}
                curved
                isAnimated
                animationDuration={800}
                color={forecasts[0].color}
                color2={forecasts[1].color}
                color3={forecasts[2].color}
                thickness={2.5}
                thickness2={2.5}
                thickness3={2.5}
                hideDataPoints={true}
                hideDataPoints2={true}
                hideDataPoints3={true}
                spacing={Math.min(35, Math.max(12, (screenWidth - 140) / Math.max(1, forecastDatasets[0].data.length)))}
                initialSpacing={10}
                endSpacing={10}
                noOfSections={4}
                yAxisColor="transparent"
                xAxisColor={colors.tabBarBorder}
                yAxisTextStyle={styles.axisText}
                xAxisLabelTextStyle={styles.axisText}
                showVerticalLines={false}
                rulesColor={colors.tabBarBorder}
                rulesType="dashed"
                adjustToWidth={true}
              />
            </View>
          </>
        ) : (
          <Text style={styles.noDataText}>Недостаточно данных для построения прогноза</Text>
        )}
      </Card>

        <View style={styles.bottomSpacing} />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  centerContainer: {
    flex: 1,
    backgroundColor: colors.background,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  headerContainer: {
    paddingTop: 60,
    paddingBottom: 24,
    paddingHorizontal: 20,
    backgroundColor: colors.background,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '700',
    fontFamily: 'Montserrat_700Bold',
    color: colors.textPrimary,
    letterSpacing: 0.3,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  chartContainer: {
    marginTop: 8,
    marginBottom: 4,
    overflow: 'hidden',
  },
  loadingText: {
    fontSize: 18,
    fontFamily: 'Montserrat_400Regular',
    color: colors.textSecondary,
  },
  emptyText: {
    fontSize: 20,
    fontWeight: '600',
    fontFamily: 'Montserrat_600SemiBold',
    color: colors.textPrimary,
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 16,
    fontFamily: 'Montserrat_400Regular',
    color: colors.textSecondary,
    textAlign: 'center',
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '700',
    fontFamily: 'Montserrat_700Bold',
    color: colors.textPrimary,
    marginBottom: 16,
  },
  periodSelector: {
    flexDirection: 'row',
    marginBottom: 16,
    backgroundColor: '#F0F4F8',
    borderRadius: 16,
    padding: 4,
  },
  periodButton: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 12,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 12,
  },
  periodButtonActive: {
    backgroundColor: colors.primary,
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 2,
  },
  periodButtonText: {
    fontSize: 13,
    fontFamily: 'Montserrat_500Medium',
    color: colors.textSecondary,
  },
  periodButtonTextActive: {
    fontFamily: 'Montserrat_600SemiBold',
    color: '#FFFFFF',
  },
  axisText: {
    fontSize: 10,
    fontFamily: 'Montserrat_400Regular',
    color: colors.textSecondary,
  },
  tooltip: {
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    marginLeft: -50,
    marginTop: -40,
  },
  tooltipValue: {
    fontSize: 16,
    fontFamily: 'Montserrat_600SemiBold',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  tooltipLabel: {
    fontSize: 12,
    fontFamily: 'Montserrat_400Regular',
    color: '#CCCCCC',
  },
  legendTitle: {
    fontSize: 13,
    fontWeight: '600',
    fontFamily: 'Montserrat_600SemiBold',
    color: colors.textPrimary,
    marginTop: 12,
    marginBottom: 12,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    paddingVertical: 4,
  },
  legendDot: {
    width: 14,
    height: 14,
    borderRadius: 7,
    marginRight: 10,
  },
  legendTextContainer: {
    flex: 1,
  },
  legendText: {
    fontSize: 14,
    fontFamily: 'Montserrat_600SemiBold',
    color: colors.textPrimary,
    marginBottom: 2,
  },
  legendDate: {
    fontSize: 12,
    fontFamily: 'Montserrat_400Regular',
    color: colors.textSecondary,
  },
  noDataText: {
    fontSize: 14,
    fontFamily: 'Montserrat_400Regular',
    color: colors.textSecondary,
    textAlign: 'center',
    marginVertical: 40,
  },
  bottomSpacing: {
    height: 100,
  },
});
