import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
} from 'react-native';
import { Card } from '../components/Card';
import { colors } from '../styles/colors';
import { supabase } from '../services/supabase';
import {
  calculateBMI,
  getBMICategory,
  calculateBodyFat,
  calculateBMR,
  calculateTDEE,
  calculateDailyCalories,
} from '../utils/calculations';

export const DashboardScreen = ({ onAddEntry }) => {
  const [userData, setUserData] = useState(null);
  const [latestEntry, setLatestEntry] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: userProfile } = await supabase
        .from('users')
        .select('*')
        .eq('id', user.id)
        .single();

      setUserData(userProfile);

      const { data: entries } = await supabase
        .from('entries')
        .select('*')
        .eq('user_id', user.id)
        .order('date', { ascending: false })
        .limit(1);

      if (entries && entries.length > 0) {
        setLatestEntry(entries[0]);
      }
    } catch (error) {
      console.error('Ошибка загрузки данных:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  }, []);

  if (loading) {
    return (
      <View style={styles.container}>
        <View style={styles.skeletonContainer}>
          <View style={styles.skeletonHero} />
          <View style={styles.skeletonRow}>
            <View style={styles.skeletonSmall} />
            <View style={styles.skeletonSmall} />
          </View>
          <View style={styles.skeletonRow}>
            <View style={styles.skeletonSmall} />
            <View style={styles.skeletonSmall} />
          </View>
        </View>
      </View>
    );
  }

  if (!userData) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Ошибка загрузки данных</Text>
      </View>
    );
  }

  const currentWeight = latestEntry ? latestEntry.weight : userData.current_weight;
  const weightToLose = currentWeight - userData.goal_weight;
  const bmi = calculateBMI(currentWeight, userData.height);
  const bmiCategory = getBMICategory(bmi);

  let bodyFatPercentage = null;
  if (latestEntry && latestEntry.waist && latestEntry.neck) {
    bodyFatPercentage = calculateBodyFat(
      userData.gender,
      latestEntry.waist,
      latestEntry.neck,
      userData.height,
      latestEntry.hips
    );
  }

  const bmr = calculateBMR(userData.gender, currentWeight, userData.height, userData.age);
  const tdee = calculateTDEE(bmr, userData.activity_level);
  const dailyCalories = calculateDailyCalories(tdee, userData.pace);

  // Прогресс к цели (от начального веса к целевому)
  const initialWeight = userData.current_weight;
  const totalToLose = initialWeight - userData.goal_weight;
  const progressPercent = totalToLose > 0
    ? Math.min(100, Math.max(0, ((initialWeight - currentWeight) / totalToLose) * 100))
    : 0;

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Доброе утро';
    if (hour < 18) return 'Добрый день';
    return 'Добрый вечер';
  };

  // Цвет ИМТ
  const getBMIColor = () => {
    if (bmi < 18.5) return colors.pastelBlue;
    if (bmi < 25) return colors.pastelMint;
    if (bmi < 30) return colors.pastelYellow;
    return colors.pastelCoral;
  };

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl refreshing={Boolean(refreshing)} onRefresh={onRefresh} />
        }
      >
        {/* Приветствие */}
        <View style={styles.greetingContainer}>
          <Text style={styles.greeting}>{getGreeting()} 👋</Text>
          <Text style={styles.greetingSub}>Давайте проверим прогресс</Text>
        </View>

        {/* Hero карточка — текущий вес + прогресс */}
        <Card color={colors.pastelPink} style={styles.heroCard}>
          <View style={styles.heroTop}>
            <View>
              <Text style={styles.heroLabel}>Текущий вес</Text>
              <View style={styles.heroWeightRow}>
                <Text style={styles.heroBigValue}>{currentWeight.toFixed(1)}</Text>
                <Text style={styles.heroUnit}>кг</Text>
              </View>
            </View>
            <Text style={styles.heroEmoji}>⚖️</Text>
          </View>

          {/* Progress bar к цели */}
          <View style={styles.heroProgressSection}>
            <View style={styles.heroProgressBar}>
              <View style={[styles.heroProgressFill, { width: `${progressPercent}%` }]} />
            </View>
            <View style={styles.heroProgressLabels}>
              <Text style={styles.heroProgressStart}>{initialWeight} кг</Text>
              <Text style={styles.heroProgressEnd}>🎯 {userData.goal_weight} кг</Text>
            </View>
            {weightToLose > 0 ? (
              <Text style={styles.heroRemainingText}>Осталось {weightToLose.toFixed(1)} кг до цели</Text>
            ) : (
              <Text style={styles.heroAchievedText}>🎉 Цель достигнута!</Text>
            )}
          </View>
        </Card>

        {/* 2x2 Виджеты */}
        <View style={styles.widgetRow}>
          <Card color={getBMIColor()} style={styles.smallCard}>
            <Text style={styles.cardEmoji}>📊</Text>
            <Text style={styles.smallCardTitle}>ИМТ</Text>
            <Text style={styles.mediumValue}>{bmi.toFixed(1)}</Text>
            <Text style={styles.smallCategory}>{bmiCategory}</Text>
          </Card>

          <Card color={colors.pastelYellow} style={styles.smallCard}>
            <Text style={styles.cardEmoji}>🎯</Text>
            <Text style={styles.smallCardTitle}>Цель</Text>
            <Text style={styles.mediumValue}>{userData.goal_weight.toFixed(1)}</Text>
            <Text style={styles.smallCategory}>кг</Text>
          </Card>
        </View>

        <View style={styles.widgetRow}>
          <Card color={bodyFatPercentage !== null ? colors.pastelCoral : colors.pastelSage} style={styles.smallCard}>
            <Text style={styles.cardEmoji}>{bodyFatPercentage !== null ? '💪' : '📝'}</Text>
            <Text style={styles.smallCardTitle}>{bodyFatPercentage !== null ? '% Жира' : 'Измерения'}</Text>
            <Text style={styles.mediumValue}>
              {bodyFatPercentage !== null ? `${bodyFatPercentage.toFixed(1)}` : '—'}
            </Text>
            <Text style={styles.smallCategory}>
              {bodyFatPercentage !== null ? 'процент' : 'добавьте'}
            </Text>
          </Card>

          <Card color={colors.pastelBlue} style={styles.smallCard}>
            <Text style={styles.cardEmoji}>🔥</Text>
            <Text style={styles.smallCardTitle}>Калории</Text>
            <Text style={styles.mediumValue}>{Math.round(dailyCalories)}</Text>
            <Text style={styles.smallCategory}>в день</Text>
          </Card>
        </View>

        {/* TDEE Info */}
        <Card color={colors.pastelLavender} style={styles.infoCard}>
          <View style={styles.infoRow}>
            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>BMR</Text>
              <Text style={styles.infoValue}>{Math.round(bmr)}</Text>
            </View>
            <View style={styles.infoSep} />
            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>TDEE</Text>
              <Text style={styles.infoValue}>{Math.round(tdee)}</Text>
            </View>
            <View style={styles.infoSep} />
            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>Темп</Text>
              <Text style={styles.infoValue}>{userData.pace === 'fast' ? 'Быстр.' : userData.pace === 'optimal' ? 'Опт.' : 'Медл.'}</Text>
            </View>
          </View>
        </Card>

        <View style={styles.bottomSpacing} />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingTop: 16,
  },

  // Skeleton loading
  skeletonContainer: {
    padding: 20,
    paddingTop: 16,
  },
  skeletonHero: {
    height: 180,
    borderRadius: 28,
    backgroundColor: '#EEF1F4',
    marginBottom: 16,
  },
  skeletonRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 12,
  },
  skeletonSmall: {
    flex: 1,
    height: 140,
    borderRadius: 28,
    backgroundColor: '#EEF1F4',
  },

  errorText: {
    fontSize: 18,
    fontFamily: 'Montserrat_400Regular',
    color: '#FF5252',
    textAlign: 'center',
    marginTop: 100,
  },

  // Greeting
  greetingContainer: {
    marginBottom: 20,
  },
  greeting: {
    fontSize: 28,
    fontWeight: '700',
    fontFamily: 'Montserrat_700Bold',
    color: colors.textPrimary,
    marginBottom: 2,
  },
  greetingSub: {
    fontSize: 15,
    fontFamily: 'Montserrat_400Regular',
    color: colors.textSecondary,
  },

  // Hero card
  heroCard: {
    padding: 24,
  },
  heroTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  heroLabel: {
    fontSize: 13,
    fontFamily: 'Montserrat_500Medium',
    color: colors.textSecondary,
    marginBottom: 6,
  },
  heroWeightRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 4,
  },
  heroBigValue: {
    fontSize: 52,
    fontWeight: '700',
    fontFamily: 'Montserrat_700Bold',
    color: colors.textPrimary,
    lineHeight: 58,
  },
  heroUnit: {
    fontSize: 18,
    fontFamily: 'Montserrat_500Medium',
    color: colors.textSecondary,
  },
  heroEmoji: {
    fontSize: 44,
  },

  // Hero progress
  heroProgressSection: {
    marginTop: 4,
  },
  heroProgressBar: {
    height: 8,
    backgroundColor: 'rgba(255,255,255,0.6)',
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 10,
  },
  heroProgressFill: {
    height: '100%',
    backgroundColor: colors.primary,
    borderRadius: 4,
  },
  heroProgressLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  heroProgressStart: {
    fontSize: 12,
    fontFamily: 'Montserrat_500Medium',
    color: colors.textSecondary,
  },
  heroProgressEnd: {
    fontSize: 12,
    fontFamily: 'Montserrat_600SemiBold',
    color: colors.textPrimary,
  },
  heroRemainingText: {
    fontSize: 14,
    fontFamily: 'Montserrat_600SemiBold',
    color: colors.primary,
  },
  heroAchievedText: {
    fontSize: 15,
    fontFamily: 'Montserrat_700Bold',
    color: colors.success,
  },

  // Widget grid
  widgetRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 12,
  },
  smallCard: {
    flex: 1,
    minHeight: 140,
    padding: 20,
  },
  cardEmoji: {
    fontSize: 28,
    marginBottom: 10,
  },
  smallCardTitle: {
    fontSize: 12,
    fontFamily: 'Montserrat_500Medium',
    color: colors.textSecondary,
    marginBottom: 6,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  mediumValue: {
    fontSize: 30,
    fontWeight: '700',
    fontFamily: 'Montserrat_700Bold',
    color: colors.textPrimary,
    marginBottom: 2,
  },
  smallCategory: {
    fontSize: 12,
    fontFamily: 'Montserrat_400Regular',
    color: colors.textSecondary,
  },

  // Info row (BMR / TDEE / Pace)
  infoCard: {
    marginTop: 4,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  infoItem: {
    alignItems: 'center',
    flex: 1,
  },
  infoLabel: {
    fontSize: 11,
    fontFamily: 'Montserrat_500Medium',
    color: colors.textSecondary,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 4,
  },
  infoValue: {
    fontSize: 18,
    fontWeight: '700',
    fontFamily: 'Montserrat_700Bold',
    color: colors.textPrimary,
  },
  infoSep: {
    width: 1,
    height: 36,
    backgroundColor: 'rgba(0,0,0,0.08)',
  },

  bottomSpacing: {
    height: 100,
  },
});
