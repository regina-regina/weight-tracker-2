import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import { Input } from '../components/Input';
import { Button } from '../components/Button';
import { Card } from '../components/Card';
import { colors } from '../styles/colors';
import { activityLevels, paces, genders } from '../utils/constants';
import { supabase } from '../services/supabase';

const TOTAL_STEPS = 4;

export const OnboardingScreen = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);

  const [gender, setGender] = useState('female');
  const [age, setAge] = useState('');
  const [height, setHeight] = useState('');
  const [currentWeight, setCurrentWeight] = useState('');
  const [goalWeight, setGoalWeight] = useState('');
  const [activityLevel, setActivityLevel] = useState('moderate');
  const [pace, setPace] = useState('optimal');

  // Валидация полей с диапазонами
  const validateStep = () => {
    switch (step) {
      case 1: {
        if (!gender) return 'Укажите пол';
        if (!age || isNaN(age) || Number(age) < 10 || Number(age) > 120)
          return 'Возраст должен быть от 10 до 120 лет';
        if (!height || isNaN(height) || Number(height) < 100 || Number(height) > 250)
          return 'Рост должен быть от 100 до 250 см';
        return null;
      }
      case 2: {
        if (!currentWeight || isNaN(currentWeight) || Number(currentWeight) < 20 || Number(currentWeight) > 500)
          return 'Текущий вес должен быть от 20 до 500 кг';
        if (!goalWeight || isNaN(goalWeight) || Number(goalWeight) < 20 || Number(goalWeight) > 500)
          return 'Целевой вес должен быть от 20 до 500 кг';
        if (Number(goalWeight) >= Number(currentWeight))
          return 'Целевой вес должен быть меньше текущего';
        return null;
      }
      case 3:
        return activityLevel ? null : 'Выберите уровень активности';
      case 4:
        return pace ? null : 'Выберите темп похудения';
      default:
        return null;
    }
  };

  const handleNext = () => {
    const error = validateStep();
    if (error) {
      Alert.alert('Проверьте данные', error);
      return;
    }
    if (step < TOTAL_STEPS) {
      setStep(step + 1);
    } else {
      handleComplete();
    }
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleComplete = async () => {
    setLoading(true);
    try {
      const { data: { user }, error: authError } = await supabase.auth.getUser();
      if (authError || !user) throw new Error('Ошибка аутентификации');

      const { error: userError } = await supabase.from('users').insert([
        {
          id: user.id,
          gender,
          age: parseInt(age),
          height: parseFloat(height),
          current_weight: parseFloat(currentWeight),
          goal_weight: parseFloat(goalWeight),
          activity_level: activityLevel,
          pace,
        },
      ]);

      if (userError) throw userError;
      onComplete();
    } catch (error) {
      Alert.alert('Ошибка', error.message);
    } finally {
      setLoading(false);
    }
  };

  // Эмодзи и цвета для каждого шага
  const stepConfig = [
    { emoji: '👤', color: colors.pastelPink, title: 'Основные данные' },
    { emoji: '🎯', color: colors.pastelMint, title: 'Ваши цели' },
    { emoji: '🏃', color: colors.pastelLavender, title: 'Уровень активности' },
    { emoji: '⚡', color: colors.pastelPeach, title: 'Темп похудения' },
  ];

  const current = stepConfig[step - 1];

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      enabled={true}
    >
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
        {/* Progress Bar */}
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: `${(step / TOTAL_STEPS) * 100}%` }]} />
          </View>
          <Text style={styles.progressText}>Шаг {step} из {TOTAL_STEPS}</Text>
        </View>

        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.emoji}>{current.emoji}</Text>
          <Text style={styles.title}>{current.title}</Text>
        </View>

        {/* Step 1 */}
        {step === 1 && (
          <Card color={current.color}>
            <Text style={styles.label}>Пол</Text>
            <View style={styles.optionsRow}>
              {genders.map((g) => (
                <TouchableOpacity
                  key={g.value}
                  style={[styles.option, gender === g.value && styles.optionSelected]}
                  onPress={() => setGender(g.value)}
                >
                  <Text style={[styles.optionText, gender === g.value && styles.optionTextSelected]}>
                    {g.value === 'male' ? '♂️ ' : '♀️ '}{g.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <Input label="Возраст (лет)" value={age} onChangeText={setAge} placeholder="Например, 25" keyboardType="numeric" />
            <Input label="Рост (см)" value={height} onChangeText={setHeight} placeholder="Например, 165" keyboardType="numeric" />
          </Card>
        )}

        {/* Step 2 */}
        {step === 2 && (
          <Card color={current.color}>
            <Input label="Текущий вес (кг)" value={currentWeight} onChangeText={setCurrentWeight} placeholder="Например, 70" keyboardType="numeric" />
            <Input label="Целевой вес (кг)" value={goalWeight} onChangeText={setGoalWeight} placeholder="Например, 60" keyboardType="numeric" />

            {currentWeight && goalWeight && Number(currentWeight) > Number(goalWeight) && (
              <View style={styles.goalPreview}>
                <Text style={styles.goalPreviewText}>
                  Нужно похудеть на <Text style={styles.goalPreviewBold}>{(Number(currentWeight) - Number(goalWeight)).toFixed(1)} кг</Text>
                </Text>
              </View>
            )}
          </Card>
        )}

        {/* Step 3 */}
        {step === 3 && (
          <Card color={current.color}>
            {activityLevels.map((level) => (
              <TouchableOpacity
                key={level.value}
                style={[styles.listOption, activityLevel === level.value && styles.listOptionSelected]}
                onPress={() => setActivityLevel(level.value)}
              >
                <View style={styles.listOptionInner}>
                  <View>
                    <Text style={styles.listOptionTitle}>{level.label}</Text>
                    <Text style={styles.listOptionDescription}>{level.description}</Text>
                  </View>
                  {activityLevel === level.value && (
                    <View style={styles.checkmark}>
                      <Text style={styles.checkmarkIcon}>✓</Text>
                    </View>
                  )}
                </View>
              </TouchableOpacity>
            ))}
          </Card>
        )}

        {/* Step 4 */}
        {step === 4 && (
          <Card color={current.color}>
            {paces.map((p) => (
              <TouchableOpacity
                key={p.value}
                style={[styles.listOption, pace === p.value && styles.listOptionSelected]}
                onPress={() => setPace(p.value)}
              >
                <View style={styles.listOptionInner}>
                  <View>
                    <Text style={styles.listOptionTitle}>{p.label}</Text>
                    <Text style={styles.listOptionDescription}>{p.description}</Text>
                  </View>
                  <View style={[styles.paceDot, { backgroundColor: p.color }]} />
                </View>
              </TouchableOpacity>
            ))}
          </Card>
        )}

        {/* Кнопки навигации */}
        <View style={styles.buttonContainer}>
          {step > 1 && (
            <Button title="Назад" onPress={handleBack} variant="secondary" style={styles.buttonNav} />
          )}
          <Button
            title={step === TOTAL_STEPS ? '🎉 Завершить' : 'Далее →'}
            onPress={handleNext}
            loading={loading}
            style={step > 1 ? styles.buttonNav : styles.buttonNavFull}
          />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingTop: 56,
  },

  // Progress bar
  progressContainer: {
    marginBottom: 32,
  },
  progressBar: {
    height: 6,
    backgroundColor: '#F0F4F8',
    borderRadius: 3,
    overflow: 'hidden',
    marginBottom: 10,
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.primary,
    borderRadius: 3,
  },
  progressText: {
    fontSize: 13,
    fontFamily: 'Montserrat_600SemiBold',
    color: colors.primary,
    textAlign: 'right',
  },

  // Header
  header: {
    alignItems: 'center',
    marginBottom: 24,
  },
  emoji: {
    fontSize: 48,
    marginBottom: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    fontFamily: 'Montserrat_700Bold',
    color: colors.textPrimary,
    textAlign: 'center',
  },

  // Labels & options
  label: {
    fontSize: 14,
    fontWeight: '600',
    fontFamily: 'Montserrat_600SemiBold',
    color: colors.textSecondary,
    marginBottom: 12,
  },
  optionsRow: {
    flexDirection: 'row',
    marginBottom: 20,
    gap: 12,
  },
  option: {
    flex: 1,
    padding: 16,
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
    borderWidth: 2,
    borderColor: '#F0F4F8',
    alignItems: 'center',
  },
  optionSelected: {
    borderColor: colors.primary,
    backgroundColor: colors.primary,
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  optionText: {
    fontSize: 16,
    fontWeight: '600',
    fontFamily: 'Montserrat_600SemiBold',
    color: colors.textPrimary,
  },
  optionTextSelected: {
    color: '#FFFFFF',
  },

  // List options (activity / pace)
  listOption: {
    padding: 18,
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
    marginBottom: 12,
    borderWidth: 2,
    borderColor: '#F0F4F8',
  },
  listOptionSelected: {
    borderColor: colors.primary,
    backgroundColor: colors.pastelPink,
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 2,
  },
  listOptionInner: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  listOptionTitle: {
    fontSize: 16,
    fontWeight: '700',
    fontFamily: 'Montserrat_700Bold',
    color: colors.textPrimary,
    marginBottom: 4,
  },
  listOptionDescription: {
    fontSize: 14,
    fontFamily: 'Montserrat_400Regular',
    color: colors.textSecondary,
  },
  checkmark: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkmarkIcon: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
  paceDot: {
    width: 20,
    height: 20,
    borderRadius: 10,
  },

  // Goal preview
  goalPreview: {
    marginTop: 8,
    padding: 14,
    borderRadius: 16,
    backgroundColor: 'rgba(127, 217, 193, 0.2)',
  },
  goalPreviewText: {
    fontSize: 14,
    fontFamily: 'Montserrat_500Medium',
    color: colors.textSecondary,
    textAlign: 'center',
  },
  goalPreviewBold: {
    fontFamily: 'Montserrat_700Bold',
    color: colors.success,
  },

  // Buttons
  buttonContainer: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 24,
  },
  buttonNav: {
    flex: 1,
  },
  buttonNavFull: {
    flex: 1,
  },
});
